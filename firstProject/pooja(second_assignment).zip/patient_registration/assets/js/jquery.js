

//  $(document).ready(function(){
//    $("#submit").click(function(e){
//     const name = $("#name").val();
//     const email = $("#employeremail").val();
//     const cellPhone = $("#cell-phone").val();
//     const homephone = $("#home-phone").val();
//     const mobilenumber = $("#mobilenumber").val();
//     const cellphone1 = $("#cell-phone2").val();
//     const address = $("#address").val();
//     const city = $("#city").val();
//     const state = $("#state").val();
//     const zip = $("#zip").val();
//     const employername = $("#employername").val();
//     const date = $("#date").val();
//     const parent = $("#parent").val();
//     const reffered = $("#reffered").val();
//     const social = $("#social").val();
//     const occupation = $("#occupation").val();
//     const conditions = $("#conditions").val();
//     const medications = $("#medications").val();
//     const familydoctor = $("#familydoctor").val();
//     const allergies = $("#allergies").val();
//     const examdate = $("#examdate").val();
//     const eye = $("#eye").val();
//     const insurancename1 = $("#insurancename1").val();
//     const insurancename2 = $("#insurancename2").val();
//     const employer1 = $("#employer1").val();
//     const employer2 = $("#employer2").val();
//     const insuredname1 = $("#insuredname1").val();
//     const insuredname2 = $("#insuredname2").val();
//     const birthdate1 = $("#birthdate1").val();
//     const birthdate2 = $("#birthdate2").val();
//     const insuredss1 = $("#insuredss1").val();
//     const insuredss2 = $("#insuredss2").val();

//     let count = 32;
//     // validation for name
//     if(!(isNaN(name)) || name == ""){
//         if (!(isNaN(name)) && name != "") {
//             $("#name1").html("please enter a string");
//             count++;
//         }  else if (name == "") {
//             $("#name1").html("name is required");
//             count++;
//         }
//     }  else {
//         $("#name1").html("");
//         count--;
//     }

//     // validation for email
//     if (email== ""){
//         $("#employeremail1").html("email is required");
       
//     }  else {
//         $("#employeremail1").html("");
//         count--;
//     }
   
//     //  validation for cell phone
//     if (cellPhone == ""){
//         $("#cellphone1").html("cell phone is required");
       
//     }  else {
//         $("#cellphone1").html("");
//         count--;
//     }


//     // validation for home phone
//     if (homephone == "" || homephone.length < 10 || homephone.length > 10){
//         if (homephone == ""){
//             $("#homenumber").html("home phone is required");
//             count++;
//         } else if (homephone.length < 10) {
//             $("#homenumber").html("please enter 10 digits");
//             count++;
//         }  else if (homephone.length > 10) {
//             $("#homenumber").html("please enter 10 digits");
//             count++;
//         }
//     }  else {
//         $("#homenumber").html("");
//         count--;
//     }

//      // validation for home phone
//      if (mobilenumber == "" || mobilenumber.length < 10 || mobilenumber.length > 10){
//         if (mobilenumber == ""){
//             $("#mobilenumber1").html("home phone is required");
//             count++;
//         } else if (mobilenumber.length < 10) {
//             $("#mobilenumber1").html("please enter 10 digits");
//         }  else if (mobilenumber.length > 10) {
//             $("#mobilenumber1").html("please enter 10 digits");
//         } else if (isNaN(mobilenumber)) {
//             $("#mobilenumber1").html("please enter number");
//         }
//     }  else {
//         $("#mobilenumber1").html("");
//         count--;
//     }
    
//     // validation for cell phone
//     if (cellphone1 == ""){
//         $("#cellphone2").html("cell phone is required");
       
//     }  else {
//         $("#cellphone2").html("");
//         count--;
//     }

    
//     if (address == "") {
//         $("#address1").html("address is required");
//         count++;
//     } else {
//         $("#address1").html("");
//         count--;
//     }

//     // // city validation
//     if (city == "") {
//         $("#city1").html("city is required");
//         count++;
//     } else {
//         $("#city1").html("");
//         count--;
//     }

//     //   state validation
//     if (state == "") {
//         $("#state1").html("state is required");
//         count++;
//     } else {
//         $("#state1").html("");
//         count--;
//     }

//    // zip validation
//     if (zip == "") {
//         $("#zip1").html("zip file is required");
//         count++;
//     } else {
//         $("#zip1").html("");
//         count--;
//     }

//     // employer name validation
//     if (employername == "") {
//         $("#employername1").html("employer's name is required");
//         count++;
//     } else {
//         $("#employername1").html("");
//         count--;
//     }

//     // date validation
//     if (date == "") {
//         $("#date1").html("birth date is required");
//         count++;
//     } else {
//         $("#date1").html("");
//         count--;
//     }

//     // parent validation
//     if (parent == "") {
//         $("#parent1").html("this field is required");
//         count++;
//     } else {
//         $("#parent1").innerHTML = "";
//         count--;
//     }

//     //   reffered validation
//     if (reffered == "") {
//         $("#reffered1").html("this field is required");
//         count++;
//     } else {
//         $("#reffered1").html("");
//         count--;
//     }


//     // social security validation
//     if (social == "") {
//         $("#social1").html("this field is required");
//         count++;
//     } else {
//         $("#social1").html("");
//         count--;
//     }

//     //   occupation  validation
//     if (occupation == "") {
//         $("#occupation1").html("this field is required");
//         count++;
//     } else {
//         $("#occupation1").html("");
//         count--;
//     }

//      //   conditions validation
//     if (conditions == "") {
//         $("#conditions1").html("this field is required");
//         count++;
//     } else {
//         $("#conditions1").html("");
//         count--;
//     }


//      // medications validation
//       if (medications == "") {
//         $("#medications1").html("this field is required");
//         count++;
//     } else {
//         $("#medications1").html("");
//         count--;
//     }
   

//      //  familydoctor validation
//      if (familydoctor == "") {
//         $("#familydoctor1").html("this field is required");
//         count++;
//     } else {
//         $("#familydoctor1").html("");
//         count--;
//     }

//      //allergies validation
//      if (allergies == "") {
//         $("#allergies1").html("this field is required");
//         count++;
//     } else {
//         $("#allergies1").html("");
//         count--;
//     }


//     //examdate validation
//     if (examdate == "") {
//         $("#examdate1").html("this field is required");
//         count++;
//     } else {
//         $("#examdate1").html("");
//         count--;
//     }
   
//      //eye disorders validation
//      if (eye == "") {
//         $("#eye1").html("this field is required");
//         count++;
//     } else {
//         $("#eye1").html("");
//         count--;
//     }
   
//      //insurancename1 validation
//      if (insurancename1 == "") {
//         $("#insurancename11").html("this field is required");
//         count++;
//     } else {
//         $("#insurancename11").html("");
//         count--;
//     }
   
//      // insurancename2  validation
//      if (insurancename2  == "") {
//         $("#insurancename22").html("this field is required");
//         count++;
//     } else {
//         $("#insurancename22").html("");
//         count--;
//     }

//     //employer1 validation
//     if (employer1 == "") {
//         $("#employer11").html("this field is required");
//         count++;
//     } else {
//         $("#employer11").html("");
//         count--;
//     }
   
//      // employer2 validation
//      if (employer2  == "") {
//         $("#employer22").html("this field is required");
//         count++;
//     } else {
//         $("#employer22").html("");
//         count--;
//     }

//     // insuredname1 validation
//     if ( insuredname1 == "") {
//         $("#insuredname11").html("this field is required");
//         count++;
//     } else {
//         $("#insuredname11").html("");
//         count--;
//     }
   
//      //  insuredname2  validation
//      if ( insuredname2 == "") {
//         $("#insuredname22").html("this field is required");
//         count++;
//     } else {
//         $("#insuredname22").html("");
//         count--;
//     }


//      //  birthdate1  validation
//      if (birthdate1 == "") {
//         $("#birthdate11").html("this field is required");
//         count++;
//     } else {
//         $("#birthdate11").html("");
//         count--;
//     }
   
//      //  birthdate2  validation
//      if (birthdate2== "") {
//         $("#birthdate22").html("this field is required");
//         count++;
//     } else {
//         $("birthdate22").html("");
//         count--;
//     }
   
//      //  insuredss1 validation
//      if (insuredss1 == "") {
//         $("#insuredss11").html("this field is required");
//         count++;
//     } else {
//         $("#insuredss11").html("");
//         count--;
//     }
   
//      // insuredss2 validation
//      if (insuredss2 == "") {
//         $("#insuredss22").html("this field is required");
//         count++;
//     } else {
//         $("#insuredss22").html("");
//         count--;
//     }
   
    
   


   
//     if (count == 0){

//     } else {
//         e.preventDefault();
//     }
     

// });
// });














// //     let para = document.createElement('p');

// //     para.textContent = " title : " + title1 + ", <br> Marital Status: " + status1 + ", <br>  Name : " + name + ", <br> EMail : " + email + ", <br> Address : " + address + ", <br> Cell Phone: " + cellPhone + ", <br> Home Phone: "
// //         + homephone + ", <br> Mobile Number: " + mobilenumber + ", <br> Cell Phone: " + cellphone1 + ", <br> City: " + city
// //         + ", <br> state: " + state + ", <br> Zip: " + zip + ", <br> Employer's Name: " + employername + ", <br> Date: " + date + ", <br> Parent: " + parent
// //         + ", <br> Reffered: " + reffered + ", <br> Social Security: " + social + ", <br> Occupation: " + occupation + ", <br> Other Condition(s): " + conditions
// //         + ", <br> Medications are you presently: " + medications + ", <br> Name of family doctor: " + familydoctor + ", <br> List any allergies to medications:"
// //         + allergies + ", <br> Date of last exam: " + examdate + ", <br> Do you smoke?: " + smoke1 + ", <br> Family history of eye disorders " + eye + ", <br> insurancename1: " + insurancename1
// //         + ", <br> Insurance Name: " + insurancename1 + ", <br> Insurance Name: " + insurancename2 + ", <br> Employer" + employer1 + ", <br> Employer"
// //         + employer2 + ", <br> Insured's Name: "  + ", <br> Did you ever where glasses or contact lenses: "  + glasses1  + insuredname1 + ", <br> Insured's Name: " + insuredname2 + ", <br> Birth Date: " + birthdate1 +
// //         ", <br> Birth Date: " + birthdate2 + ", <br> Insured's ss: " + insuredss1 + ", <br> Insured's ss: " + insuredss2;

// //     paracontent = para.textContent;
// //     if (count == 0) {
// //         document.getElementById("myform").style.display = 'none' && document.write(paracontent);
// //     }
// //     e.preventDefault();
// // }




